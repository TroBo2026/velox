# VELOX 0.9.8 – Fehlerbehebungen und Feinschliff

Ergebnis einer vollständigen Code-Durchsicht von `app.js`, `analysis-pro.js`, `elevation-core.js`, `sensor-core.js`, `sw.js`, `index.html`, `styles.css`, `manifest.webmanifest` und der CI-Workflows.

## Kritischer Fehler

- **Tour starten brach ab, bevor die GPS-Aufzeichnung begann.** In `startRide()` wurde die nicht deklarierte Variable `liveLine` gesetzt (gemeint war `liveLines`). Da `app.js` im Strict Mode läuft, löst das einen `ReferenceError` aus. Er trat nach dem Aktivieren der Schaltflächen auf, aber vor `watchPosition`. Es wurden also keine GPS-Punkte aufgezeichnet.

## Weitere Fehler

- **Zweite Tour während einer laufenden Tour:** Der „Tour starten“-Button der Startseite blieb aktiv. Ein weiterer Klick ersetzte die laufende Tour im Speicher, ließ das alte GPS-Abo weiterlaufen und die alte Tour unvollständig in der Datenbank zurück. Jetzt wird der zweite Start abgefangen.
- **Geisterstrecke auf der Live-Karte:** Ältere Linien und der Marker wurden beim Neuaufbau nur aus der Liste gelöscht, aber nie von der Karte entfernt. Nach jeder Tour und bei jedem Besuch der Track-Seite blieben Duplikate sichtbar. Neu: `clearLiveLayers()`.
- **Karte teilte sich bei Stillstand:** Identische GPS-Positionen (Ampel, Pause) zerlegten die Route in viele Abschnitte. Das verfälschte die Anzeige „n GPS-Abschnitte“ und erzeugte unnötige `<trkseg>`-Elemente im GPX-Export. Stillstand trennt jetzt nicht mehr; echte Lücken (über 180 s) trennen weiterhin.
- **Race Condition beim Speichern:** `pauseRide()` schrieb am Speicher-Queue vorbei. Ein noch wartender älterer Schreibvorgang konnte den Status „pausiert“ mit „recording“ überschreiben. Alle Schreibvorgänge laufen jetzt über `persistActiveRide()`.
- **Überholter GPS-Callback:** Ein Fix, der während des Beendens noch gespeichert wurde, überschrieb danach den Status „Tour gespeichert“ mit „Aufzeichnung läuft“.
- **Detailkarte nach Wiederverbindung:** `restoreOnlineMaps()` initialisierte die Karte erneut, ohne die bestehende zu entfernen („Map container is already initialized“). Die Kartenlogik ist jetzt in `drawDetailMap()` zusammengefasst.
- **Leaflet wurde beim Start immer geladen**, obwohl seit 0.9.2 „nur bei Bedarf“ dokumentiert ist. Die persönliche Routenkarte funktionierte nur dadurch. Jetzt lädt sie Leaflet selbst nach, der App-Start nicht mehr.
- **Offline wiederhergestellte Tour:** `init()` überschrieb die wiederhergestellte Route mit einer leeren Offline-Ansicht.
- **Live-Anzeige blieb nach dem Beenden stehen** und zeigte beim nächsten Besuch der Track-Seite noch die Werte der letzten Tour.
- **„Alle Daten löschen“ während einer laufenden Tour** leerte die Datenbank unter der Aufzeichnung weg. Jetzt wird das mit Hinweis abgelehnt. Das Löschen einer noch laufenden Tour aus der Detailansicht ebenso.
- **Automatisches Wetter funktionierte für frische Fahrten praktisch nie:** Das Open-Meteo-Archiv liegt einige Tage zurück, also lieferte es für heute nur leere Werte, und es blieb bei der manuellen Eingabe. Jetzt gibt es einen Rückfall auf die Analysedaten der letzten Tage (nur für Fahrten der letzten 10 Tage). Außerdem wird `AbortSignal.timeout` nur noch benutzt, wenn es existiert.
- **Barometer-Fusion (`sensor-core.js`):** `fuseAltitude` wird mit dem Zeitstempel des GPS-Fixes aufgerufen. Lag er vor dem Barometer-Zeitstempel (üblich), wurde der Barometerwert als „aus der Zukunft“ verworfen. Es gilt jetzt eine Toleranz von 2 s.
- **Service Worker:** Die README versprach „Cache zuerst, im Hintergrund aktualisieren“, tatsächlich wurde nie nachgeladen. Jetzt echtes Stale-While-Revalidate. Der Precache lädt mit `cache: "reload"`, damit nie alte und neue Dateien gemischt werden. Cache-Version `v27`.
- **Logo erschien in einer Serifenschrift:** `.brand` nutzte `font-family: Manrope` ohne Fallback, die Schrift wird aber seit 0.9.2 nicht mehr geladen.
- **Installierte iOS-Web-App:** Mit `black-translucent` und `viewport-fit=cover` lag die Kopfzeile unter Uhr und Notch. Safe-Area-Abstände ergänzt.
- **Kleinere Punkte:** `haversine` gegen `NaN` abgesichert; `Math.min/max(...große Arrays)` durch sichere Schleifen ersetzt (Stack-Risiko bei sehr langen Touren); Fehler beim Export, Löschen und Navigieren werden gemeldet statt unbehandelt zu bleiben; GPX-Dateiname wird bereinigt; Download-Link wird für iOS ins DOM eingehängt.

## Verbesserungen

- **Bildschirm bleibt während der Aufzeichnung an** (Screen Wake Lock API, wo iOS sie anbietet). Das mindert das größte dokumentierte Problem der PWA.
- **Weniger Rechenlast bei langen Touren:** Live-Kennzahlen und Kartenlinien werden höchstens alle 2 bis 2,5 s neu berechnet statt bei jedem GPS-Fix; abgeschlossene Touren werden pro Seitenaufruf nur einmal ausgewertet.
- **Persistenter Speicher** wird angefragt, damit Safari lokale Touren seltener automatisch räumt.
- **Datenbank:** `onversionchange` schließt die Verbindung, damit künftige Schema-Updates nicht blockieren.
- **Barrierefreiheit:** `aria-current` in der Navigation, `type="button"` an allen Schaltflächen, Touch-Ziele mindestens 44 px, `<noscript>`-Hinweis.
- **SVG-Icons** statt der Textzeichen ▶ und ↗ auf dem Track-Button (iOS zeigt ▶ als Emoji).
- **CI:** Neuer Workflow `web-check.yml` mit Syntaxprüfung, Manifest- und Offline-Cache-Prüfung und Logik-Tests (`tests/`).

## Nicht geändert, aber aufgefallen

- Die README beschreibt noch Version 0.9.3, der Code ist 0.9.7/0.9.8. In der Dateitabelle fehlt `elevation-core.js`. Außerdem steht dort, der Zeitstempel der Barometer-Bridge sei optional, der Code verlangt ihn aber.
- **`apple-touch-icon` fehlt.** iOS nutzt für das Home-Bildschirm-Icon kein SVG. Empfohlen: ein 180×180-px-PNG und `<link rel="apple-touch-icon" href="./icon-180.png">`. Binärdateien konnte ich hier nicht erzeugen.
- Leaflet kommt von unpkg.com. Besser selbst hosten (auch offline nützlich) oder mit Subresource Integrity absichern.
- `elevation-core` und `analysis-pro` behandeln Stillstand unterschiedlich: Die Pro-Analyse lässt Höhenwerte im Stand aus, der Kern trennt dafür Höhensegmente. Das ist eine Designfrage und wirkt sich nur auf Höhenmeter-Feinheiten aus. Ich habe es bewusst nicht angefasst.
- `analysis-pro.js` enthält doppelte CSS-Regeln und trägt noch die Versionsnummer 0.8.1.

## Nicht getestet

Ich konnte keinen echten iPhone-Test und keine Netzwerkzugriffe durchführen. Syntaxprüfung und die Logik-Tests in `tests/` laufen sauber. Das Verhalten von Wake Lock, die Open-Meteo-Rückfallabfrage und GPS auf dem Gerät müssen real geprüft werden.
